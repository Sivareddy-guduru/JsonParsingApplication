package com.androidexample.myapp;

public class DetailObject {
	private String Id;
	private String Name;
	public DetailObject(String Id, String Name){
		this.Id=Id;
		this.Name=Name;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}

}
