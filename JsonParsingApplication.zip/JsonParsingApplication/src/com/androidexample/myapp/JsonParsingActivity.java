package com.androidexample.myapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class JsonParsingActivity extends Activity {
	String serverURL = "https://api.github.com/gists/public";
	JSONArray array = null;
	ListViewAdapter mAdapter;
	int length;
	ListViewAdapter mAdapterOne;
	ListView listview;
	ArrayList<DetailObject> list;
	ArrayList<DetailObject> finalList;
	static int count;
	TextView text;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private boolean haveNetworkConnection() {
		boolean haveConnectedWifi = false;
		boolean haveConnectedMobile = false;

		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo[] netInfo = cm.getAllNetworkInfo();
		for (NetworkInfo ni : netInfo) {
			if (ni.getTypeName().equalsIgnoreCase("WIFI"))
				if (ni.isConnected())
					haveConnectedWifi = true;
			if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
				if (ni.isConnected())
					haveConnectedMobile = true;
		}
		return haveConnectedWifi || haveConnectedMobile;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.action_add:
			if (haveNetworkConnection() && (list.size() == 0)) {
				new LongOperation().execute(serverURL);
				mAdapterOne = new ListViewAdapter(finalList, this);
				listview.setAdapter(mAdapterOne);
			}
			if (count < mAdapter.getCount())
				finalList.add((DetailObject) mAdapter.getItem(count));
			else {
				Toast.makeText(this, " THere are no items to add",
						Toast.LENGTH_LONG).show();
			}
			count++;
			mAdapterOne.notifyDataSetChanged();
			return true;

		}
		return super.onOptionsItemSelected(item);

	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater m = getMenuInflater();
		m.inflate(R.menu.context_menu, menu);
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.delete_item:
			AdapterContextMenuInfo info = (AdapterContextMenuInfo) item
					.getMenuInfo();
			int position = (int) info.id;
			list.remove(position);
			finalList.remove(position);
			mAdapterOne.notifyDataSetChanged();
			mAdapter.notifyDataSetChanged();
			return true;
		}
		return super.onContextItemSelected(item);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		list = new ArrayList<DetailObject>();
		text = (TextView) findViewById(R.id.textview);
		finalList = new ArrayList<DetailObject>();
		listview = (ListView) findViewById(R.id.listView1);
		registerForContextMenu(listview);
		length = 0;
		new LongOperation().execute(serverURL);
		mAdapterOne = new ListViewAdapter(finalList, this);
		listview.setAdapter(mAdapterOne);
		Log.i("siva", "am in oncreate");
	}

	@Override
	protected void onStop() {
		super.onStop();
		count = 0;
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		/*if (haveNetworkConnection() && (list.size() == 0)) {
			new LongOperation().execute(serverURL);
			mAdapterOne = new ListViewAdapter(finalList, this);
			listview.setAdapter(mAdapterOne);
		}*/

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt("count", count);
	}

	// Class with extends AsyncTask class
	private class LongOperation extends AsyncTask<String, Void, Void> {

		private ProgressDialog Dialog = new ProgressDialog(JsonParsingActivity.this);
		private String Error = null;

		protected void onPreExecute() {
			if (haveNetworkConnection()) {
				listview.setVisibility(View.VISIBLE);
				text.setVisibility(View.GONE);
				Dialog.setMessage("Please wait..");
				Dialog.show();
			} else {
				listview.setVisibility(View.GONE);
				text.setText("not connected to internet. Please enable mobile data or connect with wifi");
				text.setVisibility(View.VISIBLE);
			}
		}

		// Call after onPreExecute method
		protected Void doInBackground(String... Void) {

			BufferedReader reader = null;
			try {
				array = JSONParser.getJSONFromUrl(serverURL);
				length = array.length();
			} catch (NullPointerException e) {
				// TODO: handle exception
				Error = e.getMessage();
				e.printStackTrace();
				// finish();

				Dialog.dismiss();
			}

			return null;
		}

		protected void onPostExecute(Void unused) {

			// Close progress dialog
			Dialog.dismiss();
			if (Error != null) {
			} else {

				try {

					int lengthJsonArr = length;// array.length();

					for (int i = 0; i < lengthJsonArr; i++) {
						/****** Get Object for each JSON node. ***********/
						JSONObject jsonChildNode = array.getJSONObject(i)
								.getJSONObject("owner");

						/******* Fetch node values **********/
						String name = jsonChildNode.optString("login")
								.toString();
						String id = jsonChildNode.optString("id").toString();
						Log.i("siva", " server data" + " --->" + name
								+ " number " + " --->" + id);

						DetailObject mObject = new DetailObject(id, name);

						list.add(mObject);
					}
					/****************** End Parse Response JSON Data *************/

					mAdapter = new ListViewAdapter(list, JsonParsingActivity.this);
					Log.i("siva", "am in postexecute");
					Toast.makeText(JsonParsingActivity.this,
							" Press plus button to view items",
							Toast.LENGTH_SHORT).show();

				} catch (JSONException e) {

					e.printStackTrace();
				}

			}
		}
	}

}
