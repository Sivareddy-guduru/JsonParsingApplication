package com.androidexample.myapp;

import java.util.ArrayList;

import android.content.Context;
import android.os.IBinder.DeathRecipient;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListViewAdapter extends BaseAdapter {
	ArrayList<DetailObject> mlist = new ArrayList<DetailObject>();
	LayoutInflater mInflater;
	Context mContext;

	public ListViewAdapter(ArrayList<DetailObject> list, Context c) {
		mlist = list;
		mContext = c;
		mInflater = LayoutInflater.from(mContext);

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mlist.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mlist.get(arg0);
	}

	/*
	 * @Override public long getItemId(int arg0) { // TODO Auto-generated method
	 * stub return 0; }
	 */

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		MyViewHolder mViewHolder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.activity1_main, null);
			mViewHolder = new MyViewHolder();
			mViewHolder.id = (TextView) convertView.findViewById(R.id.id);
			mViewHolder.name = (TextView) convertView.findViewById(R.id.name);
			convertView.setTag(mViewHolder);
		} else {
			mViewHolder = (MyViewHolder) convertView.getTag();
		}
		DetailObject mobject = mlist.get(position);
		if (mobject != null) {
			mViewHolder.id.setText(mobject.getId());
			mViewHolder.name.setText(mobject.getName());
		}
		return convertView;
	}

	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

}

class MyViewHolder {
	TextView id;
	TextView name;
}
